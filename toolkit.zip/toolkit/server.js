var http = require('http');
var express = require('express');
var SSE = require('sse');

var app = express().use(express.static('public'));
var server = http.createServer(app);
var clients = [];


var Kafka = require('node-rdkafka');

var consumer = new Kafka.KafkaConsumer({
  'debug': 'all',
  'metadata.broker.list': '18.234.19.54:9092',
  'group.id': 'node-rdkafka-consumer-flow-example',
  'enable.auto.commit': false
});

var topicName = 'cvbsm';

//logging debug messages, if debug is enabled
consumer.on('event.log', function(log) {
  console.log(log);
});

//logging all errors
consumer.on('event.error', function(err) {
  console.error('Error from consumer');
  console.error(err);
});

//counter to commit offsets every numMessages are received
var counter = 0;
var numMessages = 5;

consumer.on('ready', function(arg) {
  console.log('consumer ready.' + JSON.stringify(arg));

  consumer.subscribe([topicName]);
  //start consuming messages
  consumer.consume();
});

consumer.on('data', function(m) {
  counter++;

  //committing offsets every numMessages
  if (counter % numMessages === 0) {
    console.log('calling commit');
    consumer.commit(m);
  }

  // Output the actual message contents
  //console.log(JSON.stringify(m));
  
  clients.forEach(function(stream) {
    stream.send(m.value.toString());
    console.log('Sent: ' + m.value.toString());
  });
  //console.log(m.value.toString());

});

consumer.on('disconnected', function(arg) {
  console.log('consumer disconnected. ' + JSON.stringify(arg));
});

//starting the consumer
consumer.connect();


// Starts node http server

server.listen(3000, '0.0.0.0', function() {
  var sse = new SSE(server);

  sse.on('connection', function(stream) {
    clients.push(stream);
    console.log('Opened connection 🎉');

    stream.on('close', function() {
      clients.splice(clients.indexOf(stream), 1);
      console.log('Closed connection 😱');
    });
  });
});


// can receive from the client with standard http and broadcast

var bodyParser = require('body-parser')
app.use(bodyParser.json())
app.post('/api', function(req, res) {
  var message = JSON.stringify(req.body);
  console.log('Received: ' + message);
  res.status(200).end();

  var json = JSON.stringify({ message: 'Something changed' });
  clients.forEach(function(stream) {
    stream.send(json);
    console.log('Sent: ' + json);
  });
})

