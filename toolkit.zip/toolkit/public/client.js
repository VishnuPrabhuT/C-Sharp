function uid() {
	return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
		(c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
	)
}

var stream = new EventSource("/sse");
stream.onopen = function () {
	//notification(uid,'Opened connection 🎉');
	//notification(uid,'Now streaming data...');
};
stream.onerror = function (event) {
	notification(uid, 'Error: ' + JSON.stringify(event));
};
stream.onmessage = function (event) {
	log(event.data);
};
document.querySelector('#close').addEventListener('click', function (event) {
	stream.close();
	notificationa('Closed connection 😱');
});
var list = document.getElementById('log');
var log = function (text) {
	vehicle(text);
}
var notification = function (id, text) {
	$("<li class='nav-item' id='" + id + "'>" + text + "</li>").hide().prependTo("#notification").fadeIn();
}
window.addEventListener('beforeunload', function () {
	stream.close();
});

// can still push to the server as usual with good old ajax
document.querySelector('#send').addEventListener('click', function (event) {
	var json = JSON.stringify({
		message: 'Hey there'
	});
	var xhr = new XMLHttpRequest();
	xhr.open('POST', '/api', true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.send(json);
	log('Sent: ' + json);
});

// Google Maps Setup

/**
 * Create new map
 
 */
function round(num) {
	return Math.ceil(num * 100) / 100;
}
/*var myOptions = {
	zoom:17,
	center: new google.maps.LatLng(34.682007, -82.829721),
	mapTypeId: 'roadmap'
};
var map = new google.maps.Map($('#map')[0], myOptions), */
var feedCompilation = '[',
	markers = {};
window.pause = false;
//latLng = new google.maps.LatLng(29.642114, -82.321859) // lat long for flrodia demo
latLng = new google.maps.LatLng(34.682007, -82.829721) // lat long for clemson perimeter road
var mapOptions = {
	center: latLng,
	zoom: 16,
	mapTypeId: google.maps.MapTypeId.ROADMAP
};
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
var cars = {};

function storeCar(carID, carParameters) {
	cars[carID] = carParameters;
}

function vehicle(data) {

	// Add data to CSV Feed
	if (data != "") {
		feedCompilation = feedCompilation.concat(data + ",");
	}

	var result = JSON.parse(data.replace(/\bNaN\b/g, "null")),
		speed = "", icon;

	console.log(result);
	storeCar(result["carid"], result);
	if (result["speed"] < 5) {
		speed = "Stopped"
	} else {
		speed = result["speed"] + " MPH"
	}
	//console.log(cars["carid"] in cars);
	// → Car Already Exists
	//console.log(cars[1]);
	// → -0.081
	if ('eventid' in result) {
		warningMsg(result["content"]);
	}
	data_rate_Analytics(result["carid"], result["data_rate"]);
	if ('carid' in result) { // Check if it is a car
		// car image in map
		icon = "https://cecas.clemson.edu/C2M2/wp-content/uploads/2017/12/car.png"

		carAnalytics(result["carid"], result["speed"]);

		//data_rate_Analytics(result["eventid"], result["carid"], result["speed"]);

		if ($("#" + result["carid"]).length == 0) { // This means this carid does not yet exist.
			var item = $("<tr id=" + result["carid"] + "><td>" + result["carid"] + "</td><td>" + round(result["longitude"]) + "</td><td>" + round(result["latitude"]) + "</td><td>" + speed + "</td><td>" + result["timestamp"] + "</td></tr>");
			$('#vehicles tbody').prepend(item);
		} else { // Carid does exist in table so just update entry
			$("#vehicles #" + result["carid"]).replaceWith("<tr id=" + result["carid"] + "><td>" + result["carid"] + "</td><td>" + round(result["longitude"]) + "</td><td>" + round(result["latitude"]) + "</td><td>" + speed + "</td><td>" + result["timestamp"] + "</td></tr>");
		}
	} else if ('rsuid' in result) { // Check if it is a Road Side Unit
		icon = "tower.png"
		if ($("#" + result["rsuid"]).length == 0) {
			var item = $("<tr id=" + result["rsuid"] + "><td>" + result["rsuid"] + "</td><td>" + round(result["longitude"]) + "</td><td>" + round(result["latitude"]) + "</td><td>" + speed + "</td><td>" + result["timestamp"] + "</td></tr>");
			$('#rsus tbody').prepend(item);
		} else {
			$("#" + result["rsuid"]).replaceWith("<tr id=" + result["rsuid"] + "><td>" + result["rsuid"] + "</td><td>" + round(result["longitude"]) + "</td><td>" + round(result["latitude"]) + "</td><td>" + speed + "</td><td>" + result["timestamp"] + "</td></tr>")
		}
	} else if ('eventid' in result) { // Check if it is an Event
		if ($("#notification #" + result["eventid"]).length == 0) {
			notification(result["eventid"], result["content"]);
		} else {
			$("#notification #" + result["eventid"]).remove();
			notification(result["eventid"], result["content"]);
		}
	}
	var latlng = new google.maps.LatLng(result['latitude'], result['longitude']);
	var marker = new google.maps.Marker({
		position: latlng,
		map: map,
		id: result["carid"],
		icon: icon
	});
	if (typeof markers[result["carid"]] === "undefined") {
		markers[result["carid"]] = marker; // cache marker in markers object
	} else {
		var mark = markers[result["carid"]]; // find marker
		mark.setMap(null); // set markers setMap to null to remove it from map
		delete markers[result["carid"]]; // delete marker instance from markers object
		markers[result["carid"]] = marker; // cache marker in markers object
	}
}

function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
	//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
	var data = JSONData.slice(0, -1).concat("]");
	console.log(data)
	var arrData = typeof data != 'object' ? JSON.parse(data) : JSONData;
	var CSV = '';
	//Set Report title in first row or line
	CSV += ReportTitle + '\r\n\n';
	//This condition will generate the Label/Header
	if (ShowLabel) {
		var row = "";
		//This loop will extract the label from 1st index of on array
		for (var index in arrData[0]) {
			//Now convert each value to string and comma-seprated
			row += index + ',';
		}
		row = row.slice(0, -1);
		//append Label row with line break
		CSV += row + '\r\n';
	}
	//1st loop is to extract each row
	for (var i = 0; i < arrData.length; i++) {
		var row = "";
		//2nd loop will extract each column and convert it in string comma-seprated
		for (var index in arrData[i]) {
			row += '"' + arrData[i][index] + '",';
		}
		row.slice(0, row.length - 1);
		//add a line break after each row
		CSV += row + '\r\n';
	}
	if (CSV == '') {
		alert("Invalid data");
		return;
	}
	//Generate a file name
	var fileName = "";
	//this will remove the blank-spaces from the title and replace it with an underscore
	fileName += ReportTitle.replace(/ /g, "_");
	//Initialize file format you want csv or xls
	var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
	// Now the little tricky part.
	// you can use either>> window.open(uri);
	// but this will not work in some browsers
	// or you will not get the correct file extension
	//this trick will generate a temp <a /> tag
	var link = document.createElement("a");
	link.href = uri;
	//set the visibility hidden so it will not effect on your web-layout
	link.style = "visibility:hidden";
	link.download = fileName + ".csv";
	//this part will append the anchor tag and remove it after automatic click
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
}
$('#vehicles a').click(function (e) {
	e.preventDefault()
	$(this).tab('show')
})
$('#rsus a').click(function (e) {
	e.preventDefault()
	$(this).tab('show')
})
$("#pause").click(function () {
	pause = !pause;
	console.log(pause)
	if (pause) {
		$("#pause").text("Start");
	} else {
		$("#pause").text("Stop");
	}
});
$(document).ready(function () {
	$(".search").keyup(function () {
		var searchTerm = $(".search").val();
		var listItem = $('.results tbody').children('tr');
		var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
		if ($(".search").length > 0) {
			pause = true;
			if (pause) {
				$("#pause").text("Start");
			} else {
				$("#pause").text("Stop");
			}
		} else {
			pause = false
		}
		$.extend($.expr[':'], {
			'containsi': function (elem, i, match, array) {
				return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
			}
		});
		$(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function (e) {
			$(this).attr('visible', 'false');
		});
		$(".results tbody tr:containsi('" + searchSplit + "')").each(function (e) {
			$(this).attr('visible', 'true');
		});
		var jobCount = $('.results tbody tr[visible="true"]').length;
		$('.counter').text(jobCount + ' item');
		if (jobCount == '0') {
			$('.no-result').show();
		} else {
			$('.no-result').hide();
		}
	});
});

/*d3.select("#analyticsBody").selectAll(".axis").data(["top", "bottom"]).enter().append("div").attr("class", function(d) {
	return d + " axis";
}).each(function(d) {
	d3.select(this).call(context.axis().ticks(12).orient(d));
});
d3.select("#analyticsBody").append("div").attr("class", "rule").call(context.rule());
d3.select("#analyticsBody").selectAll(".horizon").data(d3.range(1, 201).map(random)).enter().insert("div", ".bottom").attr("class", "horizon").call(context.horizon().extent([-10, 10]));
context.on("focus", function(i) {
	d3.selectAll(".value").style("right", i == null ? null : context.size() - i + "px");
});*/
// Replace this with context.graphite and graphite.metric!

var queueCounter = 0;
var limit = 35 * 5,
	duration = 750,
	now = new Date(Date.now() - duration);

var width = 450,
	height = 300;

var groups = {
	car1: {
		value: 0,
		color: "red",
		data: d3.range(limit).map(function () {
			return 0;
		})
	},
	car2: {
		value: 0,
		color: "blue",
		data: d3.range(limit).map(function () {
			return 0;
		})
	},
	car3: {
		value: 0,
		color: "green",
		data: d3.range(limit).map(function () {
			return 0;
		})
	},
	car4: {
		value: 0,
		color: "black",
		data: d3.range(limit).map(function () {
			return 0;
		})
	}
};

var x = d3.time
	.scale()
	.domain([now - (limit - 2), now - duration])
	.range([0, width]);

var y = d3.scale
	.linear()
	.domain([0, 40])
	.range([height, 0]);

//1

var line1 = d3.svg
	.line()
	.interpolate("basis")
	.x(function (d, i) {
		return x(now - (limit - 1 - i) * duration);
	})
	.y(function (d) {
		return y(d);
	});

var svg1 = d3
	.select("#graph1")
	.append("svg")
	.attr("class", "chart")
	.attr("width", width)
	.attr("height", height + 15);

var axis1 = svg1
	.append("g")
	.attr("class", "x axis")
	.attr("transform", "translate(0," + height + ")")
	.call(
	(x.axis = d3.svg
		.axis()
		.scale(x)
		.orient("bottom"))
	);

var axisy1 = svg1
	.append("g")
	.attr("class", "y axis")
	.attr("transform", "translate(0," + 30 + ")")
	.call(
	(y.axis = d3.svg
		.axis()
		.scale(y)
		.orient("right"))
	);

/*var axisy = svg1
  .append("g")
  .attr("class", "y axis")
  .attr("transform", "translate(0," + height + ")")
  .call(
	(y.axis = d3.svg
	  .axis()
	  .scale(y)
	  .orient("left"))
  );*/

var paths1 = svg1.append("g");

var group = groups["car1"];
group.path = paths1
	.append("path")
	.data([group.data])
	.attr("class", "car1" + " group")
	.style("stroke", group.color);

//2
var line2 = d3.svg
	.line()
	.interpolate("basis")
	.x(function (d, i) {
		return x(now - (limit - 1 - i) * duration);
	})
	.y(function (d) {
		return y(d);
	});

var svg2 = d3
	.select("#graph2")
	.append("svg")
	.attr("class", "chart")
	.attr("width", width)
	.attr("height", height + 50);

var axis2 = svg2
	.append("g")
	.attr("class", "x axis")
	.attr("transform", "translate(0," + height + ")")
	.call(
	(x.axis = d3.svg
		.axis()
		.scale(x)
		.orient("bottom"))
	);

var axisy2 = svg2
	.append("g")
	.attr("class", "y axis")
	.attr("transform", "translate(0," + 30 + ")")
	.call(
	(y.axis = d3.svg
		.axis()
		.scale(y)
		.orient("right"))
	);

var paths2 = svg2.append("g");

var group = groups["car2"];
group.path = paths2
	.append("path")
	.data([group.data])
	.attr("class", "car2" + " group")
	.style("stroke", group.color);

//3

var line3 = d3.svg
	.line()
	.interpolate("basis")
	.x(function (d, i) {
		return x(now - (limit - 1 - i) * duration);
	})
	.y(function (d) {
		return y(d);
	});

var svg3 = d3
	.select("#graph3")
	.append("svg")
	.attr("class", "chart")
	.attr("width", width)
	.attr("height", height + 50);

var axis3 = svg3
	.append("g")
	.attr("class", "x axis")
	.attr("transform", "translate(0," + height + ")")
	.call(
	(x.axis = d3.svg
		.axis()
		.scale(x)
		.orient("bottom"))
	);

var axisy3 = svg3
	.append("g")
	.attr("class", "y axis")
	.attr("transform", "translate(0," + 30 + ")")
	.call(
	(y.axis = d3.svg
		.axis()
		.scale(y)
		.orient("right"))
	);

var paths3 = svg3.append("g");

var group = groups["car3"];
group.path = paths3
	.append("path")
	.data([group.data])
	.attr("class", "car3" + " group")
	.style("stroke", group.color);

//4

var line4 = d3.svg
	.line()
	.interpolate("basis")
	.x(function (d, i) {
		return x(now - (limit - 1 - i) * duration);
	})
	.y(function (d) {
		return y(d);
	});

var svg4 = d3
	.select("#graph4")
	.append("svg")
	.attr("class", "chart")
	.attr("width", width)
	.attr("height", height + 50);

var axis4 = svg4
	.append("g")
	.attr("class", "x axis")
	.attr("transform", "translate(0," + height + ")")
	.call(
	(x.axis = d3.svg
		.axis()
		.scale(x)
		.orient("bottom"))
	);

var axisy4 = svg4
	.append("g")
	.attr("class", "y axis")
	.attr("transform", "translate(0," + 30 + ")")
	.call(
	(y.axis = d3.svg
		.axis()
		.scale(y)
		.orient("right"))
	);

var paths4 = svg4.append("g");

var group = groups["car4"];
group.path = paths4
	.append("path")
	.data([group.data])
	.attr("class", "car4" + " group")
	.style("stroke", group.color);
function warningMsg(warning) {
	if (warning == "No Queue") {
		queueCounter += 1;
	}
	//queueCounter+=1;
	if (warning == "Queue Ahead") {
		queueCounter = 0;
		$("#queue").css("background-color", "red");
		document.getElementById("queueText").innerHTML = "Queue Warning!";
		setTimeout(function () { turnOffCollision(); }, 3000);
	}
	else if (warning == "No Queue" && queueCounter > 1) {
		queueCounter += 1;
		//$("#queue").css("background-color","green");
		setTimeout(function () { turnOffQueue(); }, 1000);
	}

	if (warning.includes("Collision")) {
		$("#collision").css("background-color", "red");
		//setTimeout(function() { turnOffCyber(); }, 50000);
	}
	else if (warning == "NO DOS ATTACK") {
		$("#cyber").css("background-color", "green");
		document.getElementById("cybertext").innerHTML = "Cyber Attack Warning!";
	}
	else if (warning == "DOS ATTACK") {
		$("#cyber").css("background-color", "red");
		document.getElementById("cybertext").innerHTML = "Attack Detected (Car 3)";
		setTimeout(function () { turnOffCyber(); }, 50000);
	}
	else {
		$("#collision").css("background-color", "green");

	}
}

function turnOffQueue() {
	$("#queue").css("background-color", "green");
	document.getElementById("queueText").innerHTML = "No Queue Warning";
}
function turnOffCollision() {
	$("#collision").css("background-color", "green");
}

function turnOffCyber() {
	$("#cyber").css("background-color", "green");
}

function carAnalytics(carName = 1, carSpeed = 1) {

	function tick1() {
		now = new Date();

		// Add new values

		var group = groups["car1"];
		$("#speed1").text("Speed - " + Math.round(carSpeed) + " miles/hr");
		//alert(carSpeed);
		group.data.push(carSpeed * (carSpeed * 0.09)) // Real values arrive at irregular intervals
		group.path.attr("d", line1);
		// Shift domain
		x.domain([now - (limit - 2) * duration, now - duration]);

		// Slide x-axis left
		axis1
			.transition()
			.duration(duration)
			.ease("linear")
			.call(x.axis);

		axisy1
			.transition()
			.duration(duration)
			.ease("linear")
			.call(y.axis);

		// Slide paths left
		paths1
			.attr("transform", null)
			.transition()
			.duration(duration)
			.ease("linear")
			.attr("transform", "translate(" + x(now - (limit - 1) * duration) + ")")
			.each("end", tick1);

		// Remove oldest data point from each group

		var group = groups["car1"];
		group.data.shift();

	}

	function tick2() {
		now = new Date();

		// Add new values

		var group = groups["car2"];
		$("#speed2").text("Speed - " + Math.round(carSpeed) + " miles/hr");
		//group.data.push(group.value) // Real values arrive at irregular intervals
		group.data.push(carSpeed * (carSpeed * 0.09));
		group.path.attr("d", line2);

		// Shift domain
		x.domain([now - (limit - 2) * duration, now - duration]);

		// Slide x-axis left
		axis2
			.transition()
			.duration(duration)
			.ease("linear")
			.call(x.axis);

		axisy2
			.transition()
			.duration(duration)
			.ease("linear")
			.call(y.axis);

		// Slide paths left
		paths2
			.attr("transform", null)
			.transition()
			.duration(duration)
			.ease("linear")
			.attr("transform", "translate(" + x(now - (limit - 1) * duration) + ")")
			.each("end", tick2);

		// Remove oldest data point from each group

		var group = groups["car2"];
		group.data.shift();
	}

	function tick3() {
		now = new Date();

		// Add new values

		var group = groups["car3"];
		$("#speed3").text("Speed - " + Math.round(carSpeed) + " miles/hr");
		//group.data.push(group.value) // Real values arrive at irregular intervals
		group.data.push(carSpeed * (carSpeed * 0.09));
		//group.data.push(group.value) // Real values arrive at irregular intervals
		group.path.attr("d", line3);

		// Shift domain
		x.domain([now - (limit - 2) * duration, now - duration]);

		// Slide x-axis left
		axis3
			.transition()
			.duration(duration)
			.ease("linear")
			.call(x.axis);

		axisy3
			.transition()
			.duration(duration)
			.ease("linear")
			.call(y.axis);

		// Slide paths left
		paths3
			.attr("transform", null)
			.transition()
			.duration(duration)
			.ease("linear")
			.attr("transform", "translate(" + x(now - (limit - 1) * duration) + ")")
			.each("end", tick3);

		// Remove oldest data point from each group

		var group = groups["car3"];
		group.data.shift();
	}

	function tick4() {
		now = new Date();

		// Add new values

		var group = groups["car4"];
		$("#speed4").text("Speed - " + Math.round(carSpeed) + " miles/hr");
		//group.data.push(group.value) // Real values arrive at irregular intervals
		group.data.push(carSpeed * (carSpeed * 0.09));
		group.path.attr("d", line4);
		// Shift domain
		x.domain([now - (limit - 2) * duration, now - duration]);

		// Slide x-axis left
		axis4
			.transition()
			.duration(duration)
			.ease("linear")
			.call(x.axis);

		axisy4
			.transition()
			.duration(duration)
			.ease("linear")
			.call(y.axis);

		// Slide paths left
		paths4
			.attr("transform", null)
			.transition()
			.duration(duration)
			.ease("linear")
			.attr("transform", "translate(" + x(now - (limit - 1) * duration) + ")")
			.each("end", tick4);

		// Remove oldest data point from each group

		var group = groups["car4"];
		group.data.shift();
	}
	//console.log(carName);
	if (carName == 1) {
		tick1();
	} else if (carName == 2) {
		tick2();
	} else if (carName == 3) {
		tick3();
	} else if (carName == 4) {
		tick4();
	}
}

//Data Rate
var limit = 60 * 1,
		duration = 750,
		now = new Date(Date.now() - duration)

	var width = 1000,
		height = 500

	var datagroups = {
		0.0: {
			value: 0,
			color: "red",
			data: d3.range(limit).map(function () {
				return 0;
			})
		},
		1.0: {
			value: 0,
			color: "blue",
			data: d3.range(limit).map(function () {
				return 0;
			})
		},
		2.0: {
			value: 0,
			color: "green",
			data: d3.range(limit).map(function () {
				return 0;
			})
		},
		3.0: {
			value: 0,
			color: "black",
			data: d3.range(limit).map(function () {
				return 0;
			})
		}
	}

	var x = d3.time.scale()
		.domain([now - (limit - 2), now - duration])
		.range([0, width])

	var y = d3.scale.linear()
		.domain([0, 100])
		.range([height, 0])

	var line = d3.svg.line()
		.interpolate('basis')
		.x(function (d, i) {
			return x(now - (limit - 1 - i) * duration)
		})
		.y(function (d) {
			return y(d)
		})

	var svg = d3.select('.datagraph').append('svg')
		.attr('class', 'chart')
		.attr('width', width)
		.attr('height', height + 50)

	var axis = svg.append('g')
		.attr('class', 'x axis')
		.attr('transform', 'translate(0,' + height + ')')
		.call(x.axis = d3.svg.axis().scale(x).orient('bottom'))

	var paths = svg.append('g')

	for (var name in datagroups) {
		var group = datagroups[name]
		group.path = paths.append('path')
			.data([group.data])
			.attr('class', name + ' group')
			.style('stroke', group.color)
	}
function data_rate_Analytics(carID = 1, datarate = 5) {
	

	function tick() {
		now = new Date()

		// Add new values
		for (var name in datagroups) {
			var group = datagroups[name]
			//group.data.push(group.value) // Real values arrive at irregular intervals
			//console.log(carID, name);
			group.data.push(20 + ((Math.random() * 10) % 43))
			group.path.attr('d', line)
		}

		// Shift domain
		x.domain([now - (limit - 2) * duration, now - duration])

		// Slide x-axis left
		axis.transition()
			.duration(duration)
			.ease('linear')
			.call(x.axis)

		// Slide paths left
		paths.attr('transform', null)
			.transition()
			.duration(duration)
			.ease('linear')
			.attr('transform', 'translate(' + x(now - (limit - 1) * duration) + ')')
			.each('end', tick)

		// Remove oldest data point from each group
		for (var name in datagroups) {
			var group = datagroups[name]
			group.data.shift()
		}
	}

	tick()
}







function random(x) {
	var value = 0,
		values = [],
		i = 0,
		last;
	return context.metric(function (start, stop, step, callback) {
		start = +start, stop = +stop;
		if (isNaN(last)) last = start;
		while (last < stop) {
			last += step;
			value = Math.max(-10, Math.min(10, value + .8 * Math.random() - .4 + .2 * Math.cos(i += x * .02)));
			values.push(value);
		}
		callback(null, values = values.slice((start - stop) / step));
	}, x);
}
